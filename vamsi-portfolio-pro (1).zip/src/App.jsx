
import React from 'react';

function App() {
  return (
    <div className="p-10 text-center text-white">
      <h1 className="text-4xl font-bold">Vamsi Krishna Bhavana</h1>
      <p className="text-lg mt-4">🚀 Portfolio coming soon — your site is live!</p>
    </div>
  );
}

export default App;
